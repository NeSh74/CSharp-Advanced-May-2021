﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //T1
            string name = "Pesho";
            int age = 24;
            Person pesho = new Person()
            {
                Name = name,
                Age= age
            };
            Console.WriteLine($"{pesho .Name} - {pesho .Age}");
            //T2
            Console.WriteLine("--------------------------------");
            var noName = new Person();
            Console.WriteLine($"NoNameGuy: {noName .Name} - {noName .Age}");
            var george = new Person(24);
            Console.WriteLine($"GeorgeYears: {george .Name} - {george .Age}");
            var ivan = new Person("Ivan", 27);
            Console.WriteLine($"Ivan: {ivan .Name} - {ivan .Age}");
        }
    }
}
