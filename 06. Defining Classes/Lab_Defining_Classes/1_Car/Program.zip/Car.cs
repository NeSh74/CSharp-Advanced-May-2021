﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer

{
    public class Car
    {
        //private string make;
        //private string model;
        //private int year;

        //public string Make
        //{
        //    get { return make; }
        //    set { make = value; }
        //}
        public string  Make { get; set; }

        public string  Model { get; set; }

        public int  Year { get; set; }
    }
}
